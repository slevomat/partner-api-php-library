
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Slevomat_Client_Partner"],["c","Slevomat_Client_Response_Abstract"],["c","Slevomat_Client_Response_Failure"],["c","Slevomat_Client_Response_Success"],["c","Slevomat_Client_ResponseFactory"]];
